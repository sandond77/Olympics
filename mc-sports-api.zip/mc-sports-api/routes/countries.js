import express from 'express';
import { getCountries, getMedalCountByCountryCode } from '../lib/sportsRadarAPI';

const router = express.Router();

router.get('/', (req, res, next) => {
  getCountries().then((countries) => {
    res.send({ data: countries });
  });
});

router.get('/:countryCode/medals', (req, res, next) => {
  getMedalCountByCountryCode(req.params.countryCode).then((countries) => {
    res.send({ data: countries });
  });
});

module.exports = router;
